* Link the PR to the related issue
* If there's no issue for the PR, please, create it first
* Rebase your PR if it gets out of sync with master
* Ensure your PR does not include dist/ directory

**REMOVE THE TEXT ABOVE BEFORE CREATING THE PULL REQUEST**
