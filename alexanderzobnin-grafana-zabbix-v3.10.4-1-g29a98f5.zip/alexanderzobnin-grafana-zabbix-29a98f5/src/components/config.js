export class ZabbixAppConfigCtrl {
  constructor() { }
}
ZabbixAppConfigCtrl.templateUrl = 'components/config.html';
