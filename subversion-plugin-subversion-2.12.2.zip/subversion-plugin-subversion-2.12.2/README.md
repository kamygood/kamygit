Jenkins Subversion Plugin
=========================

Provides Jenkins integration with [Apache Subversion](http://subversion.apache.org/).

See the [Subversion Plugin page](https://plugins.jenkins.io/subversion) for more information.

Apache, Apache Subversion and Subversion are trademarks of the Apache Software Foundation.
